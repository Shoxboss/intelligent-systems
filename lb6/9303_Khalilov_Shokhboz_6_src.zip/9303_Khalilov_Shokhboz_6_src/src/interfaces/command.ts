export interface ICommand {
  n: string;
  v: string | number;
}
