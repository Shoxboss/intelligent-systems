export interface IPoint {
  x: number;
  y: number;
}
export * from "./command";
export * from "./common";
export * from "./actions";
export * from "./message";
