export enum ACTION {
  FL = "flag",
  KI = "kick",
}
