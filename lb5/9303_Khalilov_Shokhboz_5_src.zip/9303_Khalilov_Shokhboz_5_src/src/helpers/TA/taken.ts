import { getPosition } from "../location";
import { FlagCoords } from "../../constants/flagCoords";
import { ITaken, ObjectData, ITakenState } from "./interfaces";

const Taken: ITaken = {
  state: {
    teamEnemy: [],
    teamOwn: [],
  },
  setHear(input): void {
    // TODO
  },
  getObjData(obj) {
    if (!obj) return undefined;
    const objData: ObjectData = {
      f: obj.cmd.p.join(""),
      angle: 0,
      dist: 0,
    };
    switch (obj.p.length) {
      case 1:
        objData.angle = obj.p[0];
        break;
      default:
        objData.dist = obj.p[0];
        objData.angle = obj.p[1];
    }
    return objData;
  },
  setSee(input, team, side) {
    const state: ITakenState = {
      teamOwn: [],
      teamEnemy: [],
    };

    const [head, ...tail] = input;

    // time
    state.time = head;

    // ball
    state.ball = this.getObjData(
      tail.find((obj) => obj.cmd && obj.cmd.p[0] === "b")
    );

    // goal
    const gr = this.getObjData(
      tail.find((obj) => obj.cmd && obj.cmd.p.join("") === "gr")
    );
    const gl = this.getObjData(
      tail.find((obj) => obj.cmd && obj.cmd.p.join("") === "gl")
    );
    state.goalOwn = side === "l" ? gl : gr;
    state.goal = side === "l" ? gr : gl;

    // look around flags
    state.lookAroundFlags = {
      fprb: this.getObjData(
        tail.find((obj) => obj.cmd && obj.cmd.p.join("") === "fprb")
      ),
      fprc: this.getObjData(
        tail.find((obj) => obj.cmd && obj.cmd.p.join("") === "fprc")
      ),
      fprt: this.getObjData(
        tail.find((obj) => obj.cmd && obj.cmd.p.join("") === "fprt")
      ),
    };

    state.teamOwn = tail
      .filter((obj) => obj.cmd && obj.cmd.p.includes(team))
      .map((obj) => this.getObjData(obj)) as ObjectData[];

    state.teamEnemy = tail
      .filter(
        (obj) => obj.cmd && obj.cmd.p[0] === "p" && !obj.cmd.p.includes(team)
      )
      .map((obj) => this.getObjData(obj)) as ObjectData[];

    // flags count
    state.topFlagsCount = tail.filter(
      (obj) => obj.cmd && obj.cmd.p[0] === "f" && obj.cmd.p.includes("t")
    ).length;
    state.botFlagsCount = tail.filter(
      (obj) => obj.cmd && obj.cmd.p[0] === "f" && obj.cmd.p.includes("b")
    ).length;

    // console.log(state);

    this.state = state;
    return this;
  },
  getMyPos(input: any[]): number[] | null {
    const pos = getPosition(input);

    if (pos) {
      return [pos.x, pos.y];
    }
    return null;
    // const flags = input.filter(
    //   (obj) => obj.cmd && (obj.cmd.p[0] === "f" || obj.cmd.p[0] === "g")
    // );
    // if (flags.length >= 2) {
    //   let myPos = null;
    //   if (flags.length === 2) {
    //     myPos = getAnswerForTwoFlags(flags, FlagCoords);
    //   } else {
    //     myPos = coordsApi.getAnswerForThreeFlags(flags, FlagCoords);
    //   }
    //   return myPos;
    // }
    // return null;
  },
};

export default Taken;
